package com.example.wordboggle

interface NewGameListener {
    fun onNewGame()
}