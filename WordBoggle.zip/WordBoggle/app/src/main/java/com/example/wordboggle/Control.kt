package com.example.wordboggle

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView

private lateinit var score: TextView
private lateinit var newgame: Button
class Control : Fragment() , ScoreListener{
    private var newGameListener: NewGameListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_control, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        score = view.findViewById(R.id.score)
        newgame = view.findViewById(R.id.newgame)


        newgame.setOnClickListener {
            score.text = "Score: 00"
            newGameListener?.onNewGame()
        }
    }


    fun setNewGameListener(listener: NewGameListener) {
        newGameListener = listener
    }


    override fun onScoreReceived(data: Int) {
        val newScore = score.text.toString().substring(7).toInt() + data
        score.text = "Score: $newScore"

    }
}