package com.example.wordboggle

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import org.w3c.dom.Text
import java.util.regex.Pattern

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

private lateinit var a1 :Button
private lateinit var a2 :Button
private lateinit var a3 :Button
private lateinit var a4 :Button
private lateinit var a5 :Button
private lateinit var a6 :Button
private lateinit var a7 :Button
private lateinit var a8 :Button
private lateinit var a9 :Button
private lateinit var a10 :Button
private lateinit var a11 :Button
private lateinit var a12 :Button
private lateinit var a13 :Button
private lateinit var a14 :Button
private lateinit var a15 :Button
private lateinit var a16 :Button

private lateinit var word: TextView
private lateinit var clear: Button
private lateinit var submit: Button

class Game : Fragment(), OnClickListener, NewGameListener {

    val board1 = arrayOf("C","I","I","A","E","U","B","Y","T","R","I","N","E","P","S","X")
    val board2 = arrayOf("S","E","K","B","U","Y","R","B","B","R","G","A","V","U","S","D")
    val board3 = arrayOf("U", "E", "X", "A", "N", "S", "W", "I", "M", "N", "T", "H", "E", "D", "E", "A")
    val board4 = arrayOf("S", "A", "L", "O", "H", "E", "R", "O", "G", "L", "O", "I", "N", "M", "I", "D")
    val boards = listOf(board1, board2, board3, board4)

    val words1 = arrayOf("9610141112","9610111215","1495101112","5610111413","1674")
    val words2 = arrayOf("15111210","1110121615","4516","111026","3261","45627","5127","1110129","471215","1210111415")
    val words3 = arrayOf("71213411","74811","1338116","14241112","12134116","1112135","51376","74326","1425116","781112","1013411")
    val words4 = arrayOf("14117236","15678","15627","14151061","781114","1623","4768","3476","36215","32167","52361")
    val words = listOf(words1, words2, words3, words4)

    var current=0
    var current_word = ""
    var prev=0

    var TAG = "________________________________"

    var possible_move = mapOf(1 to listOf(2,5,6),
        2 to listOf(1,5,6,3,7),
        3 to listOf(2,6,7,8,4),
        4 to listOf(3,7,8),
        5 to listOf(1,2,6,9,10),
        6 to listOf(1,2,3,5,7,9,10,11),
        7 to listOf(2,3,4,6,8,10,11,12),
        8 to listOf(3,4,7,11,12),
        9 to listOf(5,6,10,13,14),
        10 to listOf(5,6,7,9,11,13,14,15),
        11 to listOf(6,7,8,10,12,14,15,16),
        12 to listOf(7,8,11,15,16),
        13 to listOf(9,10,14),
        14 to listOf(9,10,11,19,15),
        15 to listOf(10,11,12,14,16),
        16 to listOf(11,12,15))

    private var scoreListener: ScoreListener? = null
    private lateinit var  current_words :Array<String>
    private lateinit var current_board : Array<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_game, container, false)
    }

    fun setScoreListener(listener: ScoreListener) {
        scoreListener = listener
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        a1 = view.findViewById(R.id.a1)
        a2 = view.findViewById(R.id.a2)
        a3 = view.findViewById(R.id.a3)
        a4 = view.findViewById(R.id.a4)
        a5 = view.findViewById(R.id.a5)
        a6 = view.findViewById(R.id.a6)
        a7 = view.findViewById(R.id.a7)
        a8 = view.findViewById(R.id.a8)
        a9 = view.findViewById(R.id.a9)
        a10 = view.findViewById(R.id.a10)
        a11 = view.findViewById(R.id.a11)
        a12 = view.findViewById(R.id.a12)
        a13 = view.findViewById(R.id.a13)
        a14 = view.findViewById(R.id.a14)
        a15 = view.findViewById(R.id.a15)
        a16 = view.findViewById(R.id.a16)

        word = view.findViewById(R.id.word)
        clear = view.findViewById(R.id.clear)
        submit = view.findViewById(R.id.submit)

        initGame()

    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.a1 -> {
                if(move_possible(1)){
                    if(!word.text.contains(a1.text)){
                        word.text = "${word.text}${a1.text}"
                        current_word += "1"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a2 -> {
                if(move_possible(2)){
                    if(!word.text.contains(a2.text)){
                        word.text = "${word.text}${a2.text}"
                        current_word += "2"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a3 -> {
                if(move_possible(3)){
                    if(!word.text.contains(a3.text)){
                        word.text = "${word.text}${a3.text}"
                        current_word += "3"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                } }
            R.id.a4 -> {
                if(move_possible(4)){
                    if(!word.text.contains(a4.text)){
                        word.text = "${word.text}${a4.text}"
                        current_word += "4"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a5 -> {
                if(move_possible(5)){
                    if(!word.text.contains(a5.text)){
                        word.text = "${word.text}${a5.text}"
                        current_word += "5"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a6 -> {
                if(move_possible(6)){
                    if(!word.text.contains(a6.text)){
                        word.text = "${word.text}${a6.text}"
                        current_word += "6"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a7 -> {
                if(move_possible(7)){
                    if(!word.text.contains(a7.text)){
                        word.text = "${word.text}${a7.text}"
                        current_word += "7"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a8 -> {
                if(move_possible(8)){
                    if(!word.text.contains(a8.text)){
                        word.text = "${word.text}${a8.text}"
                        current_word += "8"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a9 -> {
                if(move_possible(9)){
                    if(!word.text.contains(a9.text)){
                        word.text = "${word.text}${a9.text}"
                        current_word += "9"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a10 -> {
                if(move_possible(10)){
                    if(!word.text.contains(a10.text)){
                        word.text = "${word.text}${a10.text}"
                        current_word += "10"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a11 -> {
                if(move_possible(11)){
                    if(!word.text.contains(a11.text)){
                        word.text = "${word.text}${a11.text}"
                        current_word += "11"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a12 -> {
                if(move_possible(12)){
                    if(!word.text.contains(a12.text)){
                        word.text = "${word.text}${a12.text}"
                        current_word += "12"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a13 -> {
                if(move_possible(13)){
                    if(!word.text.contains(a13.text)){
                        word.text = "${word.text}${a13.text}"
                        current_word += "13"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a14 -> {
                if(move_possible(14)){
                    if(!word.text.contains(a14.text)){
                        word.text = "${word.text}${a14.text}"
                        current_word += "14"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a15 -> {
                if(move_possible(15)){
                    if(!word.text.contains(a15.text)){
                        word.text = "${word.text}${a15.text}"
                        current_word += "15"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            R.id.a16 -> {
                if(move_possible(16)){
                    if(!word.text.contains(a16.text)){
                        word.text = "${word.text}${a16.text}"
                        current_word += "16"
                    }else{
                        Toast.makeText(context, "Character already used", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            R.id.clear -> {
                Toast.makeText(context, "clear", Toast.LENGTH_SHORT).show()
                word.text = ""
                current = 0
                prev = 0
                current_word = ""

            }

            R.id.submit -> {
                countScore()
            }
        }
    }

    private fun initGame(){

        current = 0
        prev = 0
        current_word = ""
        var random = (1..4).random()
//        var random = 1
        current_board = boards[random-1]
        current_words = words[random-1]

        val buttons = Array(16) { index -> view?.findViewById<Button>(resources.getIdentifier("a${index + 1}", "id", context?.packageName)) }
        var i = 0
        for (button in buttons) {
            button?.setText(current_board[i])
            button?.setOnClickListener(this)
            i++
        }
        clear.setOnClickListener(this)
        submit.setOnClickListener(this)
    }

    private fun move_possible(button: Int): Boolean{
        if(current == 0 && prev == 0){
            current = button
            return true
        }else{
            val a = possible_move[current]?.contains(button)
            if(a === true){
                prev = current
                current = button
                return true
            }else{
                Toast.makeText(context, "Move Not Possible", Toast.LENGTH_SHORT).show()
            }
        }
        return false
    }

    private fun countScore(){
        var score = 0
        Log.d(TAG, "countScore: $current_word $current_words")
        if(current_words.contains(current_word)){
            for(i in word.text.toString()){
                if(i == 'A' || i == 'E' || i == 'I' || i == 'O' || i == 'U') {
                    score += 5
                }else{
                    score += 1
                }
            }

            val pattern = Pattern.compile("[SZPXQ]")
            val matcher = pattern.matcher(word.text.toString())
            var count = 0
            while (matcher.find()) {
                count++
            }

            if(count > 0){
                score+=score
            }
            scoreListener?.onScoreReceived(score)
            current_word = ""
            word.text = ""
            current = 0
            prev = 0
        }else{
            Toast.makeText(context, "Wrong Word", Toast.LENGTH_SHORT).show()
            scoreListener?.onScoreReceived(-10)
            word.text = ""
            current_word = ""
            current = 0
            prev = 0
        }
    }

    override fun onNewGame() {
        initGame()
    }

}