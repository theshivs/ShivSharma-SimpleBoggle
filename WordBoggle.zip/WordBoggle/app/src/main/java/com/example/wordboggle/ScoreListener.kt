package com.example.wordboggle

interface ScoreListener {
    fun onScoreReceived(score: Int)
}
