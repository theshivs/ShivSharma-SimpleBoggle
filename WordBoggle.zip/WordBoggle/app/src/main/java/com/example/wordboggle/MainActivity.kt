package com.example.wordboggle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val game = Game()
        val control = Control()

        game.setScoreListener(control)
        control.setNewGameListener(game)

        supportFragmentManager.beginTransaction()
            .replace(R.id.game_play,game)
            .replace(R.id.control, control)
            .commit()





    }

}